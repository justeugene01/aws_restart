i




for key,value in myVehicle.items{}: